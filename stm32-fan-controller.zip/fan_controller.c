#include "fan_controller.h"
#include "stm32f4xx_adc.h"
#include "stm32f4xx_tim.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "delay.h"

// 硬件配置定义
#define FAN_PWM_PORT    GPIOA
#define FAN_PWM_PIN     GPIO_Pin_0
#define FAN_PWM_TIM     TIM2
#define FAN_PWM_CHANNEL TIM_Channel_1

#define FAN_TACH_PORT   GPIOB
#define FAN_TACH_PIN    GPIO_Pin_6
#define FAN_TACH_TIM    TIM3
#define FAN_TACH_CHANNEL TIM_Channel_1

#define TEMP_ADC_PORT   GPIOC
#define TEMP_ADC_PIN    GPIO_Pin_0
#define TEMP_ADC        ADC1
#define TEMP_ADC_CHANNEL ADC_Channel_10

// 私有函数声明
static void PWM_Configuration(void);
static void Tachometer_Configuration(void);
static void ADC_Configuration(void);
static uint16_t Read_Temperature_ADC(void);
static uint16_t Convert_ADC_To_Temperature(uint16_t adcValue);

// 初始化风扇控制器
void FanController_Init(FanController* fan, TempSpeedPoint* curve, 
                       uint16_t curvePoints, uint8_t smoothFactor) {
    // 初始化结构体成员
    fan->curve = curve;
    fan->curvePoints = curvePoints;
    fan->smoothFactor = smoothFactor;
    fan->currentTemperature = 0;
    fan->targetSpeed = 0;
    fan->currentSpeed = 0;
    fan->fanRPM = 0;
    fan->lastCaptureTime = 0;
    fan->pulseCount = 0;
    
    // 初始化硬件
    PWM_Configuration();
    Tachometer_Configuration();
    ADC_Configuration();
    
    // 初始设置为最低转速
    if (curvePoints > 0) {
        fan->targetSpeed = curve[0].speed;
    }
}

// 更新温度读数
void FanController_UpdateTemperature(FanController* fan) {
    uint16_t adcValue = Read_Temperature_ADC();
    fan->currentTemperature = Convert_ADC_To_Temperature(adcValue);
}

// 更新风扇控制
void FanController_Update(FanController* fan) {
    uint16_t temp = fan->currentTemperature;
    uint8_t newTarget = 0;
    uint8_t i;
    
    // 根据温度查找目标转速（线性插值）
    if (temp <= fan->curve[0].temperature) {
        newTarget = fan->curve[0].speed;
    } 
    else if (temp >= fan->curve[fan->curvePoints - 1].temperature) {
        newTarget = fan->curve[fan->curvePoints - 1].speed;
    } 
    else {
        // 找到温度所在的区间
        for (i = 0; i < fan->curvePoints - 1; i++) {
            if (temp >= fan->curve[i].temperature && 
                temp <= fan->curve[i+1].temperature) {
                // 计算线性插值
                uint32_t deltaTemp = fan->curve[i+1].temperature - fan->curve[i].temperature;
                uint32_t deltaSpeed = fan->curve[i+1].speed - fan->curve[i].speed;
                uint32_t offsetTemp = temp - fan->curve[i].temperature;
                
                newTarget = fan->curve[i].speed + 
                           (deltaSpeed * offsetTemp) / deltaTemp;
                break;
            }
        }
    }
    
    // 更新目标转速
    fan->targetSpeed = newTarget;
    
    // 平滑过渡到目标转速
    if (fan->currentSpeed < fan->targetSpeed) {
        fan->currentSpeed += fan->smoothFactor;
        if (fan->currentSpeed > fan->targetSpeed) {
            fan->currentSpeed = fan->targetSpeed;
        }
    } 
    else if (fan->currentSpeed > fan->targetSpeed) {
        fan->currentSpeed -= fan->smoothFactor;
        if (fan->currentSpeed < fan->targetSpeed) {
            fan->currentSpeed = fan->targetSpeed;
        }
    }
    
    // 设置PWM占空比
    uint32_t period = TIM_GetAutoreload(FAN_PWM_TIM) + 1;
    uint32_t pulse = (period * fan->currentSpeed) / 100;
    TIM_SetCompare1(FAN_PWM_TIM, pulse);
}

// 设置新的转速曲线
void FanController_SetSpeedCurve(FanController* fan, TempSpeedPoint* newCurve, 
                                uint16_t newCurvePoints) {
    fan->curve = newCurve;
    fan->curvePoints = newCurvePoints;
}

// 获取当前风扇转速
uint32_t FanController_GetRPM(FanController* fan) {
    return fan->fanRPM;
}

// 配置PWM输出
static void PWM_Configuration(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    
    // 使能时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    
    // 配置PWM引脚
    GPIO_InitStructure.GPIO_Pin = FAN_PWM_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(FAN_PWM_PORT, &GPIO_InitStructure);
    
    // 连接TIM2到GPIOA的复用功能
    GPIO_PinAFConfig(FAN_PWM_PORT, GPIO_PinSource0, GPIO_AF_TIM2);
    
    // 配置TIM2
    TIM_TimeBaseStructure.TIM_Period = 1000 - 1;  // PWM周期1ms
    TIM_TimeBaseStructure.TIM_Prescaler = 84 - 1; // 84MHz / 84 = 1MHz
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(FAN_PWM_TIM, &TIM_TimeBaseStructure);
    
    // 配置PWM模式
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(FAN_PWM_TIM, &TIM_OCInitStructure);
    
    TIM_OC1PreloadConfig(FAN_PWM_TIM, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(FAN_PWM_TIM, ENABLE);
    
    // 启动定时器
    TIM_Cmd(FAN_PWM_TIM, ENABLE);
}

// 配置转速检测
static void Tachometer_Configuration(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_ICInitTypeDef TIM_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    // 使能时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    
    // 配置转速检测引脚
    GPIO_InitStructure.GPIO_Pin = FAN_TACH_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(FAN_TACH_PORT, &GPIO_InitStructure);
    
    // 连接TIM3到GPIOB的复用功能
    GPIO_PinAFConfig(FAN_TACH_PORT, GPIO_PinSource6, GPIO_AF_TIM3);
    
    // 配置TIM3
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;
    TIM_TimeBaseStructure.TIM_Prescaler = 84 - 1;  // 84MHz / 84 = 1MHz
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(FAN_TACH_TIM, &TIM_TimeBaseStructure);
    
    // 配置输入捕获
    TIM_ICInitStructure.TIM_Channel = FAN_TACH_CHANNEL;
    TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
    TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
    TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
    TIM_ICInitStructure.TIM_ICFilter = 0x0;
    TIM_ICInit(FAN_TACH_TIM, &TIM_ICInitStructure);
    
    // 使能捕获中断
    TIM_ITConfig(FAN_TACH_TIM, TIM_IT_CC1, ENABLE);
    
    // 配置中断优先级
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    // 启动定时器
    TIM_Cmd(FAN_TACH_TIM, ENABLE);
}

// 配置ADC
static void ADC_Configuration(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    ADC_InitTypeDef ADC_InitStructure;
    ADC_CommonInitTypeDef ADC_CommonInitStructure;
    
    // 使能时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    
    // 配置ADC引脚
    GPIO_InitStructure.GPIO_Pin = TEMP_ADC_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
    GPIO_Init(TEMP_ADC_PORT, &GPIO_InitStructure);
    
    // ADC通用配置
    ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
    ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
    ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
    ADC_CommonInit(&ADC_CommonInitStructure);
    
    // ADC配置
    ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfConversion = 1;
    ADC_Init(TEMP_ADC, &ADC_InitStructure);
    
    // 使能ADC
    ADC_Cmd(TEMP_ADC, ENABLE);
}

// 读取温度ADC值
static uint16_t Read_Temperature_ADC(void) {
    // 配置ADC通道
    ADC_RegularChannelConfig(TEMP_ADC, TEMP_ADC_CHANNEL, 1, ADC_SampleTime_480Cycles);
    
    // 启动转换
    ADC_SoftwareStartConv(TEMP_ADC);
    
    // 等待转换完成
    while(ADC_GetFlagStatus(TEMP_ADC, ADC_FLAG_EOC) == RESET);
    
    // 返回结果
    return ADC_GetConversionValue(TEMP_ADC);
}

// 将ADC值转换为温度值 (°C * 10)
static uint16_t Convert_ADC_To_Temperature(uint16_t adcValue) {
    // 这里根据实际使用的温度传感器进行校准
    // 示例：假设使用NTC热敏电阻，此函数需根据实际的分压电路和NTC参数调整
    // 以下为示例转换公式，实际应用中需要校准
    
    // 假设ADC参考电压3.3V，12位ADC
    float voltage = (adcValue * 3.3f) / 4095.0f;
    
    // 根据温度传感器特性将电压转换为温度
    // 这里使用简化的线性转换，实际应用中应使用更精确的转换方式
    // 例如：对于10K NTC在25°C时的典型电路
    uint16_t temperature = (uint16_t)((voltage - 0.5f) * 100.0f);
    
    // 确保温度值合理
    if (temperature < 0) temperature = 0;
    if (temperature > 1000) temperature = 1000; // 上限100°C
    
    return temperature;
}

// 定时器3中断服务程序（用于转速测量）
void TIM3_IRQHandler(void) {
    extern FanController fan;
    uint32_t currentCaptureTime;
    
    if (TIM_GetITStatus(FAN_TACH_TIM, TIM_IT_CC1) != RESET) {
        TIM_ClearITPendingBit(FAN_TACH_TIM, TIM_IT_CC1);
        
        // 读取捕获值
        currentCaptureTime = TIM_GetCapture1(FAN_TACH_TIM);
        
        // 计算脉冲间隔并计算转速
        if (fan.lastCaptureTime != 0 && currentCaptureTime > fan.lastCaptureTime) {
            uint32_t pulsePeriod = currentCaptureTime - fan.lastCaptureTime;
            
            // 计算RPM (假设每转产生2个脉冲)
            // 1MHz计数频率，pulsePeriod为两个脉冲之间的计数
            fan.fanRPM = (60 * 1000000) / (pulsePeriod * 2);
        }
        
        fan.lastCaptureTime = currentCaptureTime;
        fan.pulseCount++;
    }
}
