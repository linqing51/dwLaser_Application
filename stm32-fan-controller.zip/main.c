#include "stm32f4xx.h"
#include "fan_controller.h"
#include "delay.h"

// 扩展的温度-转速曲线 (温度单位: °C * 10, 占空比: 0-100)
// 增加了更多控制点，使转速调节更平滑
TempSpeedPoint defaultCurve[] = {
    {200,  10},  // 20°C 时 10% 转速（低转速待机）
    {220,  15},  // 22°C 时 15% 转速
    {250,  20},  // 25°C 时 20% 转速
    {280,  30},  // 28°C 时 30% 转速
    {300,  40},  // 30°C 时 40% 转速
    {320,  50},  // 32°C 时 50% 转速
    {350,  60},  // 35°C 时 60% 转速
    {370,  70},  // 37°C 时 70% 转速
    {400,  80},  // 40°C 时 80% 转速
    {420,  90},  // 42°C 时 90% 转速
    {450, 100}   // 45°C 时 100% 转速（全速运行）
};

// 创建风扇控制器实例
FanController fan;

int main(void) {
    // 初始化系统时钟
    SystemInit();
    
    // 初始化延时函数
    Delay_Init();
    
    // 初始化风扇控制器，平滑因子设为5
    // 曲线点数自动计算，无需手动修改
    FanController_Init(&fan, defaultCurve, sizeof(defaultCurve)/sizeof(TempSpeedPoint), 5);
    
    while (1) {
        // 更新温度读数
        FanController_UpdateTemperature(&fan);
        
        // 更新风扇控制
        FanController_Update(&fan);
        
        // 100ms循环一次
        Delay_Ms(100);
    }
}

// 系统滴答定时器中断服务程序
void SysTick_Handler(void) {
    TimingDelay_Decrement();
}
