#ifndef __FAN_CONTROLLER_H
#define __FAN_CONTROLLER_H

#include "stm32f4xx.h"

// 温度-转速点结构体
typedef struct {
    uint16_t temperature;  // 温度值 (°C * 10)
    uint8_t  speed;        // 对应转速 (占空比 0-100)
} TempSpeedPoint;

// 风扇控制器结构体
typedef struct {
    // 温度-转速曲线参数
    TempSpeedPoint* curve;      // 温度-转速曲线数组
    uint16_t        curvePoints;// 曲线点数
    uint8_t         smoothFactor;// 平滑因子
    
    // 运行时数据
    uint16_t currentTemperature; // 当前温度
    uint8_t  targetSpeed;        // 目标转速
    uint8_t  currentSpeed;       // 当前转速
    uint32_t fanRPM;             // 风扇实际转速(RPM)
    
    // 硬件相关
    uint32_t lastCaptureTime;    // 上一次捕获时间
    uint32_t pulseCount;         // 脉冲计数
} FanController;

// 初始化函数
void FanController_Init(FanController* fan, TempSpeedPoint* curve, 
                       uint16_t curvePoints, uint8_t smoothFactor);

// 更新温度读数
void FanController_UpdateTemperature(FanController* fan);

// 更新风扇控制
void FanController_Update(FanController* fan);

// 设置新的转速曲线
void FanController_SetSpeedCurve(FanController* fan, TempSpeedPoint* newCurve, 
                                uint16_t newCurvePoints);

// 获取当前风扇转速
uint32_t FanController_GetRPM(FanController* fan);

#endif
